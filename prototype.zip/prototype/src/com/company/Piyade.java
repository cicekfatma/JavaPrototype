package com.company;

public interface Piyade {
    Piyade birimKLonla();
    void ozellikleriGoster();

}
